package o2o.exceptions;

public class WechatAuthOperationException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1993479841545311214L;

	public WechatAuthOperationException(String msg) {
		super(msg);
	}
	
}
