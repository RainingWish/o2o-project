package o2o.exceptions;

public class ShopCategoryOperationException extends RuntimeException{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2666778271798553854L;

	public ShopCategoryOperationException(String msg) {
		super(msg);
	}
}
