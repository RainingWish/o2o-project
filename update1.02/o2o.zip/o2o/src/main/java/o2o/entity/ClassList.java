package o2o.entity;

public class ClassList {

	//id for course
	private int id;
	
	//Code of the class ie:ELEC3509
	//here record ELEC
	private String classTitle;
	
	//here record 3509
	private int classId;
	
	//Full name of the class
	private String className;
	
	// 1: is course 2: is Lab
	private int type;
	
	//First digit: 1:Monday 2:Tuesday 3:Wed. 4:Thu. 5:Fri.
	//Second digit: 1:8:30-10:00 2:10:00-11:30 3:11:30-1:00 4:1:00-2:30 5:2:30-4:00 6:4:00-5:30 7:6:00-7:30 8:7:30-9:00
	private int time1;
	private int time2;

	public String getClassTitle() {
		return classTitle;
	}

	public void setClassTitel(String classTitle) {
		this.classTitle = classTitle;
	}

	public int getClassId() {
		return classId;
	}

	public void setClassId(int classId) {
		this.classId = classId;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getTime1() {
		return time1;
	}

	public void setTime1(int time1) {
		this.time1 = time1;
	}

	public int getTime2() {
		return time2;
	}

	public void setTime2(int time2) {
		this.time2 = time2;
	}
	
	
}

