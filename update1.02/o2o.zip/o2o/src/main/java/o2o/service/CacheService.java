package o2o.service;

public interface CacheService {

	void removeFromCache(String keyPrefix);
	
}
