package o2o.dao;

import java.util.List;

import static org.junit.Assert.assertEquals;

import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import o2o.BaseTest;
import o2o.dao.ClassListDao;
import o2o.entity.ClassList;

public class ClassListDaoTest extends BaseTest{

	@Autowired
	private ClassListDao classListDao;
	
	@Test
	@Ignore
	public void testQueryClassList() {
		List<ClassList> classList = classListDao.queryClassList();
		
		assertEquals(76, classList.size());
		System.out.println(classList.get(0).getClassTitle());
		System.out.println(classList.get(0).getClassId());
	}
	
	@Test
	@Ignore
	public void selectClassList() {
		List<ClassList> classList = classListDao.selectClassList("Circuits and Signals");
		System.out.println(classList.size());
		assertEquals(35,classList.get(0).getTime1());
		System.out.println(classList.get(0).getTime1());
		System.out.println(classList.get(0).getTime2());
		System.out.println(classList.get(1).getTime1());
	}
}

