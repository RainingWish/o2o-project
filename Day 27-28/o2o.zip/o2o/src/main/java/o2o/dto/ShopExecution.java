//Qinyao Zhang 12.8.2019
package o2o.dto;

import java.util.List;

import o2o.entity.Shop;
import o2o.enums.ShopStateEnum;

public class ShopExecution {

	//result status
	private int state;
	
	//status tag
	private String stateInfo;
	
	//shop numbers
	private int count;
	
	//management shop(add and delete shop will use)
	private Shop shop;
	
	//shop list (searching)
	private List<Shop> shopList;
	
	public ShopExecution() {
		
		
	}
	
	//constructor used on shop operation failure
	public ShopExecution(ShopStateEnum stateEnum) {
		this.state = stateEnum.getState();
		this.stateInfo = stateEnum.getStateInfo();
	}
	
	//constructor used on shop operation success
	public ShopExecution(ShopStateEnum stateEnum,Shop shop) {
		this.state = stateEnum.getState();
		this.stateInfo = stateEnum.getStateInfo();
		this.shop=shop;
	}
	
	//constructor used on shop list
	public ShopExecution(ShopStateEnum stateEnum,List<Shop> shopList) {
		this.state = stateEnum.getState();
		this.stateInfo = stateEnum.getStateInfo();
		this.shopList=shopList;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public String getStateInfo() {
		return stateInfo;
	}

	public void setStateInfo(String stateInfo) {
		this.stateInfo = stateInfo;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public Shop getShop() {
		return shop;
	}

	public void setShop(Shop shop) {
		this.shop = shop;
	}

	public List<Shop> getShopList() {
		return shopList;
	}

	public void setShopList(List<Shop> shopList) {
		this.shopList = shopList;
	}
	
	
}
