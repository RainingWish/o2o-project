package o2o.enums;

public enum ProductStateEnum {

	OFFLINE(-1, "Illigal Product"), DOWN(0, "Sold Out"), SUCCESS(1, "Operation Success"), INNER_ERROR(-1001, "Operation Fail"), EMPTY(-1002, "Product is empty");

	private int state;

	private String stateInfo;

	private ProductStateEnum(int state, String stateInfo) {
		this.state = state;
		this.stateInfo = stateInfo;
	}

	public int getState() {
		return state;
	}

	public String getStateInfo() {
		return stateInfo;
	}

	public static ProductStateEnum stateOf(int index) {
		for (ProductStateEnum state : values()) {
			if (state.getState() == index) {
				return state;
			}
		}
		return null;
	}

}
