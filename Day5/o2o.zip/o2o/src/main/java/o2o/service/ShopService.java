//Qinyao Zhang 12.8.2019
package o2o.service;

import java.io.File;

import o2o.dto.ShopExecution;
import o2o.entity.Shop;

public interface ShopService {
	
	ShopExecution addShop(Shop shop, File shopImg);

}
