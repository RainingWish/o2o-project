//Qinyao Zhang 12.8.2019
package o2o.service;

import java.io.InputStream;

import o2o.dto.ShopExecution;
import o2o.entity.Shop;

public interface ShopService {
	
	ShopExecution addShop(Shop shop, InputStream shopImgInputStraam,String fileName);

}
