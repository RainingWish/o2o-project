//Qinyao Zhang 12.8.2019
package o2o.service.impl;

import java.io.File;
import java.io.InputStream;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import o2o.dao.ShopDao;
import o2o.dto.ShopExecution;
import o2o.entity.Shop;
import o2o.enums.ShopStateEnum;
import o2o.exceptions.ShopOperationException;
import o2o.service.ShopService;
import o2o.util.ImageUtil;
import o2o.util.PathUtil;

@Service
public class ShopServiceImpl implements ShopService {
	@Autowired
	private ShopDao shopDao;
	
	@Override
	@Transactional
	public ShopExecution addShop(Shop shop, InputStream shopImgInputStream,String fileName) {

		//check null values
		if(shop==null){
			return new ShopExecution(ShopStateEnum.NULL_SHOP);
		}
		
		try {
			//give parameters initial value
			shop.setEnableStatus(0);
			shop.setCreateTime(new Date());
			shop.setLastEditTime(new Date());
			//add shop information
			int effectedNum =  shopDao.insertShop(shop);
			if(effectedNum<=0) {
				throw new ShopOperationException("create shop fail");
			}else {
				if(shopImgInputStream!=null) {
					//save image
					try {
						addShopImg(shop,shopImgInputStream,fileName);
					}catch(Exception e) {
						throw new ShopOperationException("Add Shop image Error"+e.getMessage());
					}
					
					//update picture address
					effectedNum = shopDao.updateShop(shop);
					if(effectedNum<=0) {
						throw new ShopOperationException("Update Shop image Fail");
					}
				}
			}
			
		}catch(Exception e) {
			throw new ShopOperationException("add Shop error:"+e.getMessage());
		}
		
		return new ShopExecution(ShopStateEnum.CHECK,shop);
	}

	private void addShopImg(Shop shop, InputStream shopImgInputStream,String fileName) {

		//get shop picture path
		String dest = PathUtil.getShopImagePath(shop.getShopId());
		String shopImgAddr = ImageUtil.generateThumbnail(shopImgInputStream,fileName, dest);
		shop.setShopImg(shopImgAddr);
		
	}

}
