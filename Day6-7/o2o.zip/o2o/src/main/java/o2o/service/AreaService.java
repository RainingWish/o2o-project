//Qinyao Zhang 12.6.2019
package o2o.service;

import java.util.List;

import o2o.entity.Area;

public interface AreaService {
	List<Area> getAreaList();

}
