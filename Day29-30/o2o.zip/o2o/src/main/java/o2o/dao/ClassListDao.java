package o2o.dao;

import java.util.List;

import o2o.entity.ClassList;

public interface ClassListDao {

	//list all class
	List<ClassList> queryClassList();
	
	//list selected class
	List<ClassList> selectClassList(String className);
	
	//list all course without lab
	List<ClassList> queryCourseList();
	
}
