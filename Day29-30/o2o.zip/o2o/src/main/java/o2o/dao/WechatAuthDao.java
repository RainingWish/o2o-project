package o2o.dao;

import o2o.entity.WechatAuth;

public interface WechatAuthDao {

	WechatAuth queryWechatInfoByOpenId(String openId);

	int insertWechatAuth(WechatAuth wechatAuth);
	
}
