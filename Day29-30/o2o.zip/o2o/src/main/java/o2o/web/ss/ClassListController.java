package o2o.web.ss;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import o2o.entity.ClassList;
import o2o.service.ClassListService;

@Controller
@RequestMapping("/ss")
public class ClassListController {
	
	@Autowired
	private ClassListService classListService;

	
	@RequestMapping(value="/listcourse",method=RequestMethod.GET)
	@ResponseBody
	private List<ClassList> listCourse(){
		List<ClassList> classList = new ArrayList<ClassList>();
		try {
			
			classList = classListService.getCourseList();
			
		}catch(Exception e) {
				e.printStackTrace();
			}
			return classList;		
	}
	
	
	@RequestMapping(value="/listclass",method=RequestMethod.GET)
	@ResponseBody
	private List<ClassList> listClass(){
		
		//Map<String,Object> modelMap = new HashMap<String,Object>();
		
		List<ClassList> classList = new ArrayList<ClassList>();
		
		try {
			
			classList = classListService.getClassList();
			//modelMap.put("rows", classList);
			//modelMap.put("total", classList.size());
			
		}catch(Exception e) {
			e.printStackTrace();
			//modelMap.put("success", false);
			//modelMap.put("errMsg", e.toString());
		}
		return classList;		
	}
	
	@RequestMapping(value="/selectclass",method=RequestMethod.GET)
	@ResponseBody
	private List<Integer> selectClass(){
		
		List<String> className = new ArrayList<String>();
		
		className.add("Electronics I");
		className.add("Switching Circuits");
		className.add("Basic EM and Power Engineering");
		className.add("Programming Languages");

		List<Integer> studyTime = new ArrayList<Integer>();
		
		List<ClassList> classList = new ArrayList<ClassList>();
		
		
		try {
			
			// return null if chose nothing
			if(className.size()==0) return studyTime;
			
			//get first class
			classList = classListService.getSelectClassList(className.get(0));
			
			//add first class time into array list
			studyTime.add(classList.get(0).getTime1());
			studyTime.add(classList.get(0).getTime2());
			
			if(classList.size()==2) {
				studyTime.add(classList.get(1).getTime1());
				
				if(classList.get(1).getTime2()!=0) studyTime.add(classList.get(1).getTime2());
			}	
			
			//start to add following class
			for (int i = 1; i< className.size();i++) {
				
				classList = classListService.getSelectClassList(className.get(i));
				
				//start to find is there any repeatable value
				for (int j = 0; j<studyTime.size();j++) {
					//compare with course
					//if repeated return timetable start with -1
					//studyTime.get(1),studyTime.get(2)are the gap courses
					if((studyTime.get(j)^classList.get(0).getTime1())==0 ||(studyTime.get(j)^classList.get(0).getTime2())==0) {
						studyTime.clear();
						studyTime.add(-1);
						studyTime.add(i);
						return studyTime;
					//check is there any 3 hours lab for this course
					}else if(classList.size()==2 && classList.get(1).getTime2()!=0) {
						if((studyTime.get(j)^classList.get(1).getTime1())==0 ||(studyTime.get(j)^classList.get(1).getTime2())==0) {
							studyTime.clear();
							studyTime.add(-1);
							studyTime.add(i);
							return studyTime;
						}
					// check is there 1.5 hours lab
					}else if(classList.size()==2){
						if((studyTime.get(j)^classList.get(1).getTime1())==0) {
							studyTime.clear();
							studyTime.add(-1);
							studyTime.add(i);
							return studyTime;
						}
					}
				}
				
				//after pass checking add all course and lab time to array list
				studyTime.add(classList.get(0).getTime1());
				studyTime.add(classList.get(0).getTime2());
				
				if(classList.size()==2) {
					studyTime.add(classList.get(1).getTime1());
					
					if(classList.get(1).getTime2()!=0) studyTime.add(classList.get(1).getTime2());
				}	
				
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			studyTime.clear();
		}
		return studyTime;
		
		
	}
}
