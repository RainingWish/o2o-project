package o2o.service;

import o2o.dto.WechatAuthExecution;
import o2o.entity.WechatAuth;
import o2o.exceptions.WechatAuthOperationException;

public interface WechatAuthService {

	WechatAuth getWechatAuthByOpenId(String openId);
	
	WechatAuthExecution register(WechatAuth wechatAuth) throws WechatAuthOperationException;

	
}
