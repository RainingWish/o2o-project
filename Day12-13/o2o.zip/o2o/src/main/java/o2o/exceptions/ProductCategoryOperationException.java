//Qinyao Zhang 12.19.2019
package o2o.exceptions;

public class ProductCategoryOperationException extends RuntimeException{


	private static final long serialVersionUID = 2404041201190919036L;

	public ProductCategoryOperationException(String msg) {
		super(msg);
	}
	
}
