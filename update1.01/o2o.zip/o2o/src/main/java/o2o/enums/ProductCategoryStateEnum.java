//Qinyao Zhang 12.19.2019
package o2o.enums;

public enum ProductCategoryStateEnum {
	SUCCESS(1, "seccess create"), INNER_ERROR(-1001, "fail to create"), EMPTY_LIST(-1002, "adding number less than 1");

	private int state;

	private String stateInfo;

	private ProductCategoryStateEnum(int state, String stateInfo) {
		this.state = state;
		this.stateInfo = stateInfo;
	}

	public int getState() {
		return state;
	}

	public String getStateInfo() {
		return stateInfo;
	}

	public static ProductCategoryStateEnum stateOf(int index) {
		for (ProductCategoryStateEnum state : values()) {
			if (state.getState() == index) {
				return state;
			}
		}
		return null;
	}
}
