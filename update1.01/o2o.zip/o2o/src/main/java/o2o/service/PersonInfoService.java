package o2o.service;

import o2o.entity.PersonInfo;

public interface PersonInfoService {

	PersonInfo getPersonInfoById(Long userId);
	
}
