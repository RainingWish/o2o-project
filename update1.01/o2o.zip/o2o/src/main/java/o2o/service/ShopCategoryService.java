//Qinyao Zhang 12.11.2019
package o2o.service;

import java.util.List;

import o2o.entity.ShopCategory;

public interface ShopCategoryService {
	List<ShopCategory> getShopCategoryList(ShopCategory shopCategoryCondition);
}
