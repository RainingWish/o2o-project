package o2o.service;

import java.util.List;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import o2o.BaseTest;
import o2o.entity.ClassList;

public class ClassListServiceTest extends BaseTest{

	@Autowired
	private ClassListService classListService;
	@Test
	public void testGetClassList() {
		List<ClassList> classList= classListService.getClassList();
		assertEquals(2501,classList.get(0).getClassId());
		System.out.println(classList.get(0).getClassTitle());
		System.out.println(classList.get(0).getClassId());
	}
	
}
