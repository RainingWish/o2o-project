//Qinyao Zhang 12.11.2019

package o2o.service;

import java.util.List;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import o2o.BaseTest;
import o2o.entity.ShopCategory;

public class ShopCategoryServiceTest extends BaseTest {

	@Autowired
	private ShopCategoryService shopCategoryService;

	@Test
	public void testGetShopCategoryList() {
		List<ShopCategory> shopCategoryList = shopCategoryService.getShopCategoryList(new ShopCategory());

		assertEquals("coffee", shopCategoryList.get(0).getShopCategoryName());

	}

}