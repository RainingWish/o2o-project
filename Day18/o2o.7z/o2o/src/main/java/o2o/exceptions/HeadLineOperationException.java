package o2o.exceptions;

public class HeadLineOperationException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1244930354168940379L;

	public HeadLineOperationException(String msg) {
		super(msg);
	}
}
