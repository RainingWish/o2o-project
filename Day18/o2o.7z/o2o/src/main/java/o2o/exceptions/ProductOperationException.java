package o2o.exceptions;

public class ProductOperationException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7233467992745701723L;

	public ProductOperationException(String msg) {
		super(msg);
	}
	
}
