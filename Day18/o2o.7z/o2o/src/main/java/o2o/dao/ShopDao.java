//Qinyao Zhang 12.7.2019
package o2o.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import o2o.entity.Shop;

public interface ShopDao {
	
	//Separate category check
	List<Shop> queryShopList(@Param("shopCondition") Shop shopCondition, @Param("rowIndex") int rowIndex,
			@Param("pageSize") int pageSize);
	
	int queryShopCount(@Param("shopCondition") Shop shopCondition);
	
	//check shop by using shopid
	Shop queryByShopId(long shopId);
	
	//new shop
	int insertShop(Shop shop);
	
	//update shop information
	int updateShop(Shop shop);
}
