//Qinyao Zhang 12.8.2019
package o2o.enums;

public enum ShopStateEnum {
	
	CHECK(0,"checking"),OFFLINE(-1,"anti-law Shop"),SUCCESS(1,"Operation is suncessful"),
	PASS(2,"Pass Verifivation"),INNER_ERROR(-1001,"System Error"),NULL_SHOPID(-1002,"Empty ShopId"),
	NULL_SHOP(-1003,"shop info is null");
	
	private int state;
	private String stateInfo;
	
	private ShopStateEnum(int state,String stateInfo) {
		this.state = state;
		this.stateInfo = stateInfo;
	}
	
	public int getState() {
		return state;
	}

	public String getStateInfo() {
		return stateInfo;
	}

	//base on input state number, return enum value
	public static ShopStateEnum stateOf(int state) {
		for (ShopStateEnum stateEnum:values()) {
			if(stateEnum.getState()==state) {
				return stateEnum;
			}
		}
		return null;
	}

}
