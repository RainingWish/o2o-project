//Qinyao Zhang 12.8.2019
package o2o.util;

public class PathUtil {

	private static String seperator = System.getenv("file.separator");

	public static String getImgBasePath() {

		String os = System.getProperty("os.name");
		String basePath = "";
		if (os.toLowerCase().startsWith("win")) {
			basePath = "C:/Users/Qinyao/Desktop/Picture";
		} else {
			basePath = "/home/qinyao/image";
		}
		//basePath = basePath.replace("/", seperator);

		return basePath;
	}

	public static String getShopImagePath(long shopId) {
		

		String imagePath = "/upload/shop/" + shopId + "/";
//		imagePath =imagePath.replace("/", seperator);
		return imagePath;

	}

}
