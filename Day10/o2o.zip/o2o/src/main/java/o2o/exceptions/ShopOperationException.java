//Qinyao Zhang 12.8.2019
package o2o.exceptions;

public class ShopOperationException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5415304283763828743L;

	public ShopOperationException(String msg) {
		super(msg);
	}

}
