//Qinyao Zhang 12.8.2019
//Qinyao Zhang 12.13.2019 imp
package o2o.service;

import o2o.dto.ImageHolder;
import o2o.dto.ShopExecution;
import o2o.entity.Shop;
import o2o.exceptions.ShopOperationException;

public interface ShopService {
	
	Shop getByShopId(long shopId);
	ShopExecution modifyShop(Shop shop, ImageHolder thumbnail) throws ShopOperationException;
	ShopExecution addShop(Shop shop, ImageHolder thumbnail) throws ShopOperationException;

}
